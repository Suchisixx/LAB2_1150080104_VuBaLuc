package week_02;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

public class frm_AES extends JFrame {

    /** Tên người dùng đã Login thành công; null = chưa đăng nhập. */
    private String currentUser = null;

    private JTextField txt_username;
    private JPasswordField txt_password;
    private JButton btn_sql;
    private JButton btn_register;
    private JButton btn_login;
    private JTextField txt_ticket;
    private JTextArea txt_plaintext;
    private JTextField txt_key;
    private JTextArea txt_ciphertext;
    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_save;
    private JButton btn_open;
    private JLabel lbl_status;

    public frm_AES() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("AES Cipher - Register / Login");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new EmptyBorder(14, 16, 14, 16));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel("AES-GCM - ĐĂNG KÝ / ĐĂNG NHẬP (ORACLE)");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        panel.add(lblTitle, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.gridx = 0;
        panel.add(new JLabel("Username:"), gbc);

        txt_username = new JTextField("sinhvien01");
        txt_username.setPreferredSize(new Dimension(250, 28));
        gbc.gridx = 1;
        panel.add(txt_username, gbc);

        gbc.gridy = 2;
        gbc.gridx = 0;
        panel.add(new JLabel("Password:"), gbc);

        txt_password = new JPasswordField("");
        txt_password.setPreferredSize(new Dimension(250, 28));
        gbc.gridx = 1;
        panel.add(txt_password, gbc);

        gbc.gridx = 2;
        panel.add(new JLabel("(ít nhất 8 ký tự)"), gbc);

        JPanel authBtnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        btn_sql = new JButton("Kết nối Oracle");
        btn_sql.setPreferredSize(new Dimension(170, 30));
        btn_sql.addActionListener(e -> btn_sqlActionPerformed());

        btn_register = new JButton("Register");
        btn_register.setPreferredSize(new Dimension(110, 30));
        btn_register.addActionListener(e -> btn_registerActionPerformed());

        btn_login = new JButton("Login");
        btn_login.setPreferredSize(new Dimension(110, 30));
        btn_login.addActionListener(e -> btn_loginActionPerformed());

        authBtnPanel.add(btn_sql);
        authBtnPanel.add(btn_register);
        authBtnPanel.add(btn_login);

        gbc.gridy = 3;
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        panel.add(authBtnPanel, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 4;
        gbc.gridx = 0;
        panel.add(new JLabel("Ticket:"), gbc);

        txt_ticket = new JTextField("");
        txt_ticket.setEditable(false);
        txt_ticket.setPreferredSize(new Dimension(420, 28));
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        panel.add(txt_ticket, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 5;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        panel.add(new JLabel("Plaintext:"), gbc);

        txt_plaintext = new JTextArea(3, 45);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        JScrollPane sp1 = new JScrollPane(txt_plaintext);
        sp1.setPreferredSize(new Dimension(570, 70));
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        panel.add(sp1, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 6;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(new JLabel("Key AES:"), gbc);

        txt_key = new JTextField("");
        txt_key.setPreferredSize(new Dimension(300, 28));
        gbc.gridx = 1;
        panel.add(txt_key, gbc);

        gbc.gridx = 2;
        panel.add(new JLabel("Mật khẩu để tạo khóa AES-256"), gbc);

        gbc.gridy = 7;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        panel.add(new JLabel("Ciphertext:"), gbc);

        txt_ciphertext = new JTextArea(3, 45);
        txt_ciphertext.setLineWrap(true);
        JScrollPane sp2 = new JScrollPane(txt_ciphertext);
        sp2.setPreferredSize(new Dimension(570, 70));
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        panel.add(sp2, gbc);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        btn_encrypt = new JButton("Encrypt");
        btn_encrypt.setPreferredSize(new Dimension(100, 30));
        btn_encrypt.addActionListener(e -> btn_encryptActionPerformed());

        btn_decrypt = new JButton("Decrypt");
        btn_decrypt.setPreferredSize(new Dimension(100, 30));
        btn_decrypt.addActionListener(e -> btn_decryptActionPerformed());

        btn_save = new JButton("Save File");
        btn_save.setPreferredSize(new Dimension(120, 30));
        btn_save.addActionListener(e -> btn_saveActionPerformed());

        btn_open = new JButton("Open File");
        btn_open.setPreferredSize(new Dimension(120, 30));
        btn_open.addActionListener(e -> btn_openActionPerformed());

        btnPanel.add(btn_encrypt);
        btnPanel.add(btn_decrypt);
        btnPanel.add(btn_save);
        btnPanel.add(btn_open);

        gbc.gridy = 8;
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        panel.add(btnPanel, gbc);

        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setPreferredSize(new Dimension(570, 36));
        gbc.gridy = 9;
        panel.add(lbl_status, gbc);

        setContentPane(panel);
        pack();
    }

    private void btn_sqlActionPerformed() {
        new frm_KetNoiSQL().setVisible(true);
    }

    private void btn_registerActionPerformed() {
        try {
            String user = txt_username.getText().trim();
            UserDao.register(user, txt_password.getPassword());
            HistoryDao.tryInsert("AES", "REGISTER", user, 0, 0);
            lbl_status.setText("Register thành công: " + user + ". Bấm Login để đăng nhập.");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi Oracle: " + ex.getMessage(),
                    "Lỗi Oracle", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_loginActionPerformed() {
        try {
            String user = txt_username.getText().trim();
            if (UserDao.login(user, txt_password.getPassword())) {
                currentUser = user;
                txt_ticket.setText(UserDao.newTicket());
                HistoryDao.tryInsert("AES", "LOGIN", user, 0, 0);
                lbl_status.setText("Login thành công: " + user + ". Có thể dùng Encrypt/Decrypt.");
            } else {
                currentUser = null;
                txt_ticket.setText("");
                JOptionPane.showMessageDialog(this, "Sai username hoặc mật khẩu.",
                        "Login thất bại", JOptionPane.ERROR_MESSAGE);
            }
        } catch (java.sql.SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi Oracle: " + ex.getMessage(),
                    "Lỗi Oracle", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_encryptActionPerformed() {
        if (currentUser == null) {
            JOptionPane.showMessageDialog(this, "Hãy Login trước khi dùng AES.");
            return;
        }
        String plaintext = txt_plaintext.getText();
        if (plaintext.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Plaintext trước khi mã hóa.");
            return;
        }
        try {
            String ciphertext = AESCipher.encrypt(plaintext, txt_key.getText());
            txt_ciphertext.setText(ciphertext);
            lbl_status.setText("<html>Đã mã hóa AES. " + HistoryDao.tryInsert("AES", "ENCRYPT", currentUser,
                    plaintext.length(), ciphertext.length()) + "</html>");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Mã hóa thất bại:\n" + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_decryptActionPerformed() {
        if (currentUser == null) {
            JOptionPane.showMessageDialog(this, "Hãy Login trước khi dùng AES.");
            return;
        }
        String ciphertext = txt_ciphertext.getText();
        if (ciphertext.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy nhập Ciphertext trước khi giải mã.");
            return;
        }
        try {
            String plaintext = AESCipher.decrypt(ciphertext, txt_key.getText());
            txt_plaintext.setText(plaintext);
            lbl_status.setText("<html>Đã giải mã AES. " + HistoryDao.tryInsert("AES", "DECRYPT", currentUser,
                    ciphertext.length(), plaintext.length()) + "</html>");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Giải mã thất bại: sai Key hoặc bản mã bị sửa.\n" + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_saveActionPerformed() {
        String path = FileTextIO.saveText(this, txt_ciphertext, "aes_ciphertext.txt");
        if (path != null) {
            lbl_status.setText("Đã lưu tệp: " + path);
        }
    }

    private void btn_openActionPerformed() {
        String path = FileTextIO.openText(this, txt_ciphertext);
        if (path != null) {
            lbl_status.setText("Đã mở tệp: " + path);
        }
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frm_AES().setVisible(true));
    }
}
