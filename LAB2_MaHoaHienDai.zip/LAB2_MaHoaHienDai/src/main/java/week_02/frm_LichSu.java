package week_02;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

public class frm_LichSu extends JFrame {

    private JTable tbl_history;
    private JButton btn_refresh;
    private JLabel lbl_status;

    public frm_LichSu() {
        initComponents();
        setLocationRelativeTo(null);
        tbl_history.setModel(HistoryDao.emptyModel());
        loadData();
    }

    private void initComponents() {
        setTitle("Lịch sử thao tác (Oracle Database)");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(new EmptyBorder(14, 16, 14, 16));

        JLabel lblTitle = new JLabel("LỊCH SỬ THAO TÁC - BẢNG CRYPTO_HISTORY");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        root.add(lblTitle, BorderLayout.NORTH);

        tbl_history = new JTable();
        JScrollPane scroll = new JScrollPane(tbl_history);
        scroll.setPreferredSize(new Dimension(760, 260));
        root.add(scroll, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        btn_refresh = new JButton("Tải lại");
        btn_refresh.setPreferredSize(new Dimension(110, 30));
        btn_refresh.addActionListener(e -> btn_refreshActionPerformed());

        lbl_status = new JLabel("Đang tải...");
        lbl_status.setPreferredSize(new Dimension(640, 22));

        bottom.add(btn_refresh);
        bottom.add(lbl_status);
        root.add(bottom, BorderLayout.SOUTH);

        setContentPane(root);
        pack();
    }

    /** Đọc 50 dòng mới nhất từ Oracle và hiện lên JTable. */
    private void loadData() {
        try {
            tbl_history.setModel(HistoryDao.loadLatest(50));
            lbl_status.setText("Đã tải " + tbl_history.getRowCount() + " dòng mới nhất từ crypto_history.");
        } catch (java.sql.SQLException ex) {
            lbl_status.setText("Không đọc được lịch sử: " + ex.getMessage());
        }
    }

    private void btn_refreshActionPerformed() {
        loadData();
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frm_LichSu().setVisible(true));
    }
}
