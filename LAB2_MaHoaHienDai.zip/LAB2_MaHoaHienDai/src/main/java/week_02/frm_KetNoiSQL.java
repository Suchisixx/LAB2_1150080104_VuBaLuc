package week_02;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

public class frm_KetNoiSQL extends JFrame {

    private JTextField txt_server;
    private JTextField txt_port;
    private JTextField txt_database;
    private JTextField txt_user;
    private JPasswordField txt_password;
    private JButton btn_test;
    private JButton btn_history;
    private JLabel lbl_status;

    public frm_KetNoiSQL() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("Kết nối Oracle Database");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new EmptyBorder(16, 18, 16, 18));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel("KẾT NỐI ORACLE DATABASE");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(lblTitle, gbc);

        gbc.gridwidth = 1;

        gbc.gridy = 1;
        gbc.gridx = 0;
        panel.add(new JLabel("Server:"), gbc);
        txt_server = new JTextField("127.0.0.1");
        txt_server.setPreferredSize(new Dimension(320, 28));
        gbc.gridx = 1;
        panel.add(txt_server, gbc);

        gbc.gridy = 2;
        gbc.gridx = 0;
        panel.add(new JLabel("Port:"), gbc);
        txt_port = new JTextField("1521");
        txt_port.setPreferredSize(new Dimension(120, 28));
        gbc.gridx = 1;
        panel.add(txt_port, gbc);

        gbc.gridy = 3;
        gbc.gridx = 0;
        panel.add(new JLabel("Service Name:"), gbc);
        txt_database = new JTextField("FREEPDB1");
        txt_database.setPreferredSize(new Dimension(320, 28));
        gbc.gridx = 1;
        panel.add(txt_database, gbc);

        gbc.gridy = 4;
        gbc.gridx = 0;
        panel.add(new JLabel("User:"), gbc);
        txt_user = new JTextField("lab2_user");
        txt_user.setPreferredSize(new Dimension(320, 28));
        gbc.gridx = 1;
        panel.add(txt_user, gbc);

        gbc.gridy = 5;
        gbc.gridx = 0;
        panel.add(new JLabel("Password:"), gbc);
        txt_password = new JPasswordField("");
        txt_password.setPreferredSize(new Dimension(320, 28));
        gbc.gridx = 1;
        panel.add(txt_password, gbc);

        JPanel btnPanel = new JPanel();
        btn_test = new JButton("Test Connection");
        btn_test.setPreferredSize(new Dimension(150, 30));
        btn_test.addActionListener(e -> btn_testActionPerformed());
        btn_history = new JButton("Xem lịch sử");
        btn_history.setPreferredSize(new Dimension(130, 30));
        btn_history.addActionListener(e -> btn_historyActionPerformed());
        btnPanel.add(btn_test);
        btnPanel.add(btn_history);

        gbc.gridy = 6;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(btnPanel, gbc);

        lbl_status = new JLabel("Chưa kết nối.");
        lbl_status.setPreferredSize(new Dimension(450, 40));
        gbc.gridy = 7;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(lbl_status, gbc);

        setContentPane(panel);
        pack();
    }

    private void btn_testActionPerformed() {
        try {
            int port = Integer.parseInt(txt_port.getText().trim());
            DbConfig.set(txt_server.getText().trim(), port, txt_database.getText().trim(),
                    txt_user.getText().trim(), txt_password.getPassword());
            lbl_status.setText("<html>" + DbConfig.test() + "</html>");
        } catch (Exception ex) {
            DbConfig.clear();
            lbl_status.setText("<html>Kết nối thất bại: " + ex.getMessage() + "</html>");
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Không kết nối được Oracle", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_historyActionPerformed() {
        new frm_LichSu().setVisible(true);
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frm_KetNoiSQL().setVisible(true));
    }
}
