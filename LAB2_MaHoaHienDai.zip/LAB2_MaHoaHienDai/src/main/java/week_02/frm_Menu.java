package week_02;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

public class frm_Menu extends JFrame {

    private JButton btn_des;
    private JButton btn_tripledes;
    private JButton btn_aes;
    private JButton btn_rc4;
    private JButton btn_twofish;
    private JButton btn_aesctr;
    private JButton btn_sql;
    private JButton btn_history;

    public frm_Menu() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("LAB 2 - Mã hóa đối xứng hiện đại");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new EmptyBorder(18, 22, 18, 22));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel("LAB 2 - MÃ HÓA ĐỐI XỨNG HIỆN ĐẠI");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(lblTitle, gbc);

        JLabel lblSub = new JLabel("Chọn một bài để mở form tương ứng:");
        gbc.gridy = 1;
        panel.add(lblSub, gbc);

        JPanel grid = new JPanel(new GridLayout(3, 3, 12, 10));
        btn_des = makeBtn("2.1 DES", () -> new frm_DES().setVisible(true));
        btn_tripledes = makeBtn("2.2 TripleDES", () -> new frm_TripleDES().setVisible(true));
        btn_aes = makeBtn("2.3 AES + Login", () -> new frm_AES().setVisible(true));
        btn_rc4 = makeBtn("2.4 RC4", () -> new frm_RC4().setVisible(true));
        btn_twofish = makeBtn("2.5 Twofish", () -> new frm_Twofish().setVisible(true));
        btn_aesctr = makeBtn("2.6 Nâng cao - AES-CTR", () -> new frm_AES_CTR().setVisible(true));
        btn_sql = makeBtn("Kết nối Oracle", () -> new frm_KetNoiSQL().setVisible(true));
        btn_history = makeBtn("Xem lịch sử", () -> new frm_LichSu().setVisible(true));

        grid.add(btn_des);
        grid.add(btn_tripledes);
        grid.add(btn_aes);
        grid.add(btn_rc4);
        grid.add(btn_twofish);
        grid.add(btn_aesctr);
        grid.add(btn_sql);
        grid.add(btn_history);
        grid.add(new JLabel());

        gbc.gridy = 2;
        gbc.insets = new Insets(10, 6, 10, 6);
        panel.add(grid, gbc);

        JLabel lblPython = new JLabel("Bài nâng cao 02 (AES-CBC) viết bằng Python: chạy tệp LAB2_Python/aes_cbc_gui.py.");
        gbc.gridy = 3;
        gbc.insets = new Insets(6, 6, 0, 6);
        panel.add(lblPython, gbc);

        setContentPane(panel);
        pack();
    }

    private JButton makeBtn(String text, Runnable action) {
        JButton b = new JButton(text);
        b.setPreferredSize(new Dimension(200, 30));
        b.addActionListener(e -> action.run());
        return b;
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frm_Menu().setVisible(true));
    }
}
