-- Kiem tra du lieu sau khi thuc hanh (chay bang tai khoan lab2_user tai FREEPDB1)

SELECT SYS_CONTEXT('USERENV', 'CON_NAME') AS pdb_name,
       SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA') AS current_schema
FROM dual;

SELECT user_id, username, created_at
FROM app_users
ORDER BY user_id DESC
FETCH FIRST 20 ROWS ONLY;

SELECT history_id, created_at, algorithm, operation,
       app_username, input_length, output_length
FROM crypto_history
ORDER BY history_id DESC
FETCH FIRST 50 ROWS ONLY;

SELECT COUNT(*) AS so_dong_lich_su FROM crypto_history;
